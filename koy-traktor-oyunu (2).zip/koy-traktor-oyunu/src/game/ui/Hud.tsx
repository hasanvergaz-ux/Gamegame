import { useEffect, useRef, useState, type ReactNode } from "react";
import { gameAudio } from "../audio/GameAudio";
import { cycleCamera, input, setHorn, switchVehicle, toggleDirection } from "../input";
import { useHud, useToggles } from "../store";
import { Minimap } from "./Minimap";

type HeldKey = "gas" | "brake" | "left" | "right" | "liftUp" | "liftDown" | "exSwingL" | "exSwingR" | "exBoomUp" | "exBoomDn" | "exStickIn" | "exStickOut" | "exCurl" | "exDump";

function HoldButton({ k, className, children, label }: { k: HeldKey; className: string; children: ReactNode; label: string }) {
  const [on, setOn] = useState(false);
  const set = (v: boolean) => {
    input[k] = v;
    setOn(v);
  };
  return (
    <button
      type="button"
      aria-label={label}
      className={className}
      data-on={on}
      onPointerDown={(e) => {
        e.preventDefault();
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        gameAudio.unlock();
        set(true);
      }}
      onPointerUp={() => set(false)}
      onPointerCancel={() => set(false)}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}

function Toggle({ on, onClick, icon, label }: { on?: boolean; onClick: () => void; icon: string; label: string }) {
  return (
    <button
      type="button"
      className="hud-btn"
      data-on={!!on}
      onClick={() => {
        gameAudio.unlock();
        onClick();
      }}
    >
      <i>{icon}</i>
      {label}
    </button>
  );
}

function TopBar() {
  const t = useToggles();
  const [hornOn, setHornOn] = useState(false);
  const isEx = t.vehicle === "excavator";
  const camNames = isEx ? ["Dış", "Kabin", "Kova"] : ["Dış", "Kabin", "Arka"];
  return (
    <div className="hud-bar">
      <Toggle on={isEx} onClick={switchVehicle} icon={isEx ? "🏗️" : "🚜"} label={isEx ? "Ekskavatör (V)" : "Traktör (V)"} />
      <Toggle on={t.cam !== 0} onClick={cycleCamera} icon="📷" label={camNames[t.cam]!} />
      <Toggle on={isEx ? t.exEngine : t.engine} onClick={() => t.flip(isEx ? "exEngine" : "engine")} icon="🔑" label="Kontak" />
      <Toggle on={t.head} onClick={() => t.flip("head")} icon="💡" label="Far" />
      <Toggle on={t.work} onClick={() => t.flip("work")} icon="🔦" label="İş lambası" />
      <Toggle on={t.beacon} onClick={() => t.flip("beacon")} icon="🚨" label="Çakar" />
      <button
        type="button"
        className="hud-btn"
        data-on={hornOn}
        onPointerDown={(e) => {
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          setHorn(true);
          setHornOn(true);
        }}
        onPointerUp={() => {
          setHorn(false);
          setHornOn(false);
        }}
        onPointerCancel={() => {
          setHorn(false);
          setHornOn(false);
        }}
      >
        <i>📯</i>Korna
      </button>
      <Toggle on={t.night} onClick={() => t.flip("night")} icon="🌙" label="Gece" />
      <Toggle on={t.hood} onClick={() => t.flip("hood")} icon="🔧" label="Kaput" />
      <Toggle on={t.quality === "high"} onClick={() => t.set({ quality: t.quality === "high" ? "low" : "high" })} icon="✨" label={t.quality === "high" ? "Yüksek" : "Düşük"} />
      <Toggle onClick={() => (input.resetPressed = true)} icon="↺" label="Başa dön" />
      <Toggle on={t.help} onClick={() => t.flip("help")} icon="?" label="Tuşlar" />
    </div>
  );
}

function ExGauges() {
  const h = useHud();
  const row = (label: string, pct: number, text: string, cls = "") => (
    <div className="hud-row">
      <span>{label}</span>
      <div className={`hud-meter ${cls}`}><div style={{ width: `${Math.max(0, Math.min(100, pct))}%` }} /></div>
      <em>{text}</em>
    </div>
  );
  return (
    <div className="hud-panel hud-gauges">
      <div className="hud-speed">
        <b>{Math.round(h.speed)}</b>
        <small>km/sa</small>
        <span className="hud-gear" data-rev={false}>EKSKAVATÖR</span>
      </div>
      {row("Devir", (h.rpm / 2100) * 100, String(Math.round(h.rpm)))}
      {row("Bom", ((h.exBoom + 25) / 87) * 100, `${Math.round(h.exBoom)}°`, "hud-meter-lift")}
      {row("Dirsek", ((h.exStick - 25) / 133) * 100, `${Math.round(h.exStick)}°`, "hud-meter-lift")}
      {row("Kova", ((h.exBucket + 20) / 160) * 100, `${Math.round(h.exBucket)}°`, "hud-meter-lift")}
      {row("Kova dolu", h.exLoad * 100, `%${Math.round(h.exLoad * 100)}`)}
      <div className="hud-status">
        <span data-state={h.exDigging ? "work" : "off"}>{h.exDigging ? "● Kazıyor" : "Bekliyor"}</span>
        <span>{h.surface}</span>
      </div>
      <div className="hud-area">
        Kazılan: <b>{h.exDug.toFixed(1)}</b> m³ · Dökülen: <b>{h.exMoved.toFixed(1)}</b> m³
      </div>
    </div>
  );
}

function Gauges() {
  const h = useHud();
  const dir = useToggles((s) => s.dir);
  const isEx = useToggles((s) => s.vehicle === "excavator");
  if (isEx) return <ExGauges />;
  const dekar = h.area / 1000;
  return (
    <div className="hud-panel hud-gauges">
      <div className="hud-speed">
        <b>{Math.round(h.speed)}</b>
        <small>km/sa</small>
        <span className="hud-gear" data-rev={dir < 0}>{dir > 0 ? "İLERİ" : "GERİ"}</span>
      </div>
      <div className="hud-row">
        <span>Devir</span>
        <div className="hud-meter"><div style={{ width: `${Math.min(100, (h.rpm / 2300) * 100)}%` }} /></div>
        <em>{Math.round(h.rpm)}</em>
      </div>
      <div className="hud-row">
        <span>Kaldırıcı</span>
        <div className="hud-meter hud-meter-lift"><div style={{ width: `${Math.round(h.lift * 100)}%` }} /></div>
        <em>{h.lift < 0.05 ? "AŞAĞI" : h.lift > 0.95 ? "YUKARI" : `%${Math.round(h.lift * 100)}`}</em>
      </div>
      <div className="hud-status">
        <span data-state={h.working ? "work" : h.attached ? "on" : "off"}>
          {h.working ? "● Toprak işleniyor" : h.attached ? "Kazayağı takılı" : "Alet takılı değil"}
        </span>
        <span>{h.surface}</span>
      </div>
      <div className="hud-area">
        İşlenen alan: <b>{dekar.toFixed(2)}</b> dekar
      </div>
    </div>
  );
}

function Prompt() {
  const h = useHud();
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 400);
    return () => clearInterval(id);
  }, []);
  const isEx = useToggles((s) => s.vehicle === "excavator");
  let msg = "";
  if (now - h.toastT < 3500 && h.toast) msg = h.toast;
  else if (!h.running && h.ready) msg = "Önce 🔑 Kontak'a bas (K)";
  else if (isEx) {
    if (h.exLoad > 0.95) msg = "Kova dolu — kolu kaldır, savur (Q/E) ve kovayı aç (Z)";
    else if (h.exDug === 0) msg = "Kazmak için: kolu uzat (T), bomu indir (F), kovayı kıvır (X), kolu çek (G)";
  }
  else if (h.canAttach) msg = "🔗 TAK düğmesine bas (T) — kazayağı hazır";
  else if (!h.attached && h.attachDist < 8) msg = `Geri vitese al (R) ve kazayağına geri geri yaklaş · ${h.attachDist.toFixed(1)} m`;
  else if (h.attached && h.lift > 0.5 && !h.working) msg = "▼ İNDİR ile kazayağını toprağa daldır";
  if (!msg) return null;
  return <div className="hud-prompt" data-good={h.canAttach}>{msg}</div>;
}

function Help() {
  const help = useToggles((s) => s.help);
  const isEx = useToggles((s) => s.vehicle === "excavator");
  if (!help) return null;
  const exRows: [string, string][] = [
    ["W S / ↑ ↓", "İleri / geri"], ["A D / ← →", "Dön"], ["Q E", "Kabini sola / sağa çevir"],
    ["R F", "Bom yukarı / aşağı"], ["T G", "Dirsek aç / çek"], ["X Z", "Kova kıvır / aç"],
    ["K", "Kontak"], ["V", "Traktöre geç"], ["H", "Korna"], ["L", "Far"], ["J", "İş lambası"], ["B", "Çakar"], ["N", "Gece"], ["C", "Kamera"],
  ];
  const rows: [string, string][] = isEx ? exRows : [
    ["W / ↑", "Gaz"], ["S / ↓ / Boşluk", "Fren"], ["A D / ← →", "Direksiyon"], ["R", "İleri ⇄ Geri"],
    ["K", "Kontak"], ["E", "Kaldırıcı yukarı"], ["Q", "Kaldırıcı aşağı"], ["T", "Aleti tak / çıkar"],
    ["H", "Korna"], ["L", "Far"], ["J", "İş lambası"], ["B", "Çakar"], ["N", "Gece"], ["C", "Kamera"], ["O", "Kaput"], ["V", "Ekskavatöre geç"],
  ];
  return (
    <div className="hud-panel hud-help" onClick={() => useToggles.getState().flip("help")}>
      <h3>{isEx ? "Ekskavatör tuşları" : "Tuşlar"}</h3>
      {rows.map(([k, v]) => (
        <div key={k}>
          <kbd>{k}</kbd>
          <span>{v}</span>
        </div>
      ))}
      <p>Fare ile sürükle: bakış · Tekerlek / iki parmak: yakınlaştır</p>
    </div>
  );
}

function Loading() {
  const ready = useHud((s) => s.ready);
  const [gone, setGone] = useState(false);
  const t = useRef<number | null>(null);
  useEffect(() => {
    if (ready) t.current = window.setTimeout(() => setGone(true), 900);
    return () => {
      if (t.current) clearTimeout(t.current);
    };
  }, [ready]);
  if (gone) return null;
  return (
    <div className="hud-loading" data-done={ready}>
      <h1>Köy Traktör Simülatörü</h1>
      <p>Arazi, köy ve traktör yükleniyor…</p>
      <div className="hud-spinner" />
    </div>
  );
}

export function Hud() {
  const dir = useToggles((s) => s.dir);
  const isEx = useToggles((s) => s.vehicle === "excavator");
  const canAttach = useHud((s) => s.canAttach);
  const attached = useHud((s) => s.attached);
  return (
    <>
      <TopBar />
      <Gauges />
      <Minimap />
      <Prompt />
      <Help />
      <div className="hud-steer">
        <HoldButton k="left" label="Sola" className="hud-pad">◀</HoldButton>
        <HoldButton k="right" label="Sağa" className="hud-pad">▶</HoldButton>
      </div>
      {isEx ? (
        <div className="hud-hitch hud-exc">
          <HoldButton k="exBoomUp" label="Bom yukarı" className="hud-btn hud-btn-wide"><i>▲</i>BOM</HoldButton>
          <HoldButton k="exBoomDn" label="Bom aşağı" className="hud-btn hud-btn-wide"><i>▼</i>BOM</HoldButton>
          <HoldButton k="exStickOut" label="Dirsek aç" className="hud-btn hud-btn-wide"><i>↗</i>DİRSEK</HoldButton>
          <HoldButton k="exStickIn" label="Dirsek çek" className="hud-btn hud-btn-wide"><i>↙</i>DİRSEK</HoldButton>
          <HoldButton k="exCurl" label="Kova kıvır" className="hud-btn hud-btn-wide"><i>⤵</i>KIVIR</HoldButton>
          <HoldButton k="exDump" label="Kova aç" className="hud-btn hud-btn-wide"><i>⤴</i>BOŞALT</HoldButton>
          <HoldButton k="exSwingL" label="Kabin sola" className="hud-btn hud-btn-wide"><i>↺</i>SOLA</HoldButton>
          <HoldButton k="exSwingR" label="Kabin sağa" className="hud-btn hud-btn-wide"><i>↻</i>SAĞA</HoldButton>
        </div>
      ) : (
        <div className="hud-hitch">
          <HoldButton k="liftUp" label="Kaldır" className="hud-btn hud-btn-wide">
            <i>▲</i>KALDIR
          </HoldButton>
          <HoldButton k="liftDown" label="İndir" className="hud-btn hud-btn-wide">
            <i>▼</i>İNDİR
          </HoldButton>
          <button
            type="button"
            className="hud-btn hud-btn-wide"
            data-good={canAttach}
            onClick={() => {
              gameAudio.unlock();
              input.attachPressed = true;
            }}
          >
            <i>🔗</i>{attached ? "ÇIKAR" : "TAK"}
          </button>
        </div>
      )}
      <div className="hud-pedals">
        {!isEx && (
          <button type="button" className="hud-btn hud-gearbtn" data-on={dir < 0} onClick={() => { gameAudio.unlock(); toggleDirection(); }}>
            İLERİ ⇄ GERİ
          </button>
        )}
        <div className="hud-pedal-row">
          <HoldButton k="brake" label={isEx ? "Geri" : "Fren"} className="hud-pedal hud-pedal-brake">{isEx ? "GERİ" : "FREN"}</HoldButton>
          <HoldButton k="gas" label={isEx ? "İleri" : "Gaz"} className="hud-pedal hud-pedal-gas">{isEx ? "İLERİ" : "GAZ"}</HoldButton>
        </div>
      </div>
      <Loading />
    </>
  );
}
