import { create } from "zustand";

export type CamMode = 0 | 1 | 2; // 0 = chase, 1 = cab, 2 = rear hitch view

export type Vehicle = "tractor" | "excavator";

export type Toggles = {
  vehicle: Vehicle;
  /** ignition of the excavator (the tractor uses `engine`) */
  exEngine: boolean;
  cam: CamMode;
  head: boolean;
  work: boolean;
  beacon: boolean;
  engine: boolean;
  night: boolean;
  hood: boolean;
  dir: 1 | -1;
  help: boolean;
  quality: "high" | "low";
};

type ToggleStore = Toggles & { set: (p: Partial<Toggles>) => void; flip: (k: "head" | "work" | "beacon" | "engine" | "exEngine" | "night" | "hood" | "help") => void };

function initialQuality(): "high" | "low" {
  if (typeof window === "undefined") return "high";
  const q = new URLSearchParams(window.location.search).get("q");
  if (q === "low" || q === "high") return q;
  return window.matchMedia?.("(pointer: coarse)").matches ? "low" : "high";
}

export const useToggles = create<ToggleStore>((set) => ({
  vehicle: "tractor",
  exEngine: false,
  cam: 0,
  head: false,
  work: false,
  beacon: false,
  engine: false,
  night: false,
  hood: false,
  dir: 1,
  help: false,
  quality: initialQuality(),
  set: (p) => set(p),
  flip: (k) => set((s) => ({ [k]: !s[k] }) as Partial<Toggles>),
}));

export type Hud = {
  ready: boolean;
  speed: number;
  rpm: number;
  lift: number;
  attached: boolean;
  working: boolean;
  canAttach: boolean;
  attachDist: number;
  area: number;
  surface: string;
  running: boolean;
  toast: string;
  toastT: number;
  // excavator
  exLoad: number; // bucket fill 0..1
  exDug: number; // soil dug so far (m³)
  exMoved: number; // soil dumped so far (m³)
  exBoom: number; // joint angles in degrees
  exStick: number;
  exBucket: number;
  exSwing: number;
  exDigging: boolean;
};

export const useHud = create<Hud>(() => ({
  ready: false,
  speed: 0,
  rpm: 0,
  lift: 1,
  attached: false,
  working: false,
  canAttach: false,
  attachDist: 99,
  area: 0,
  surface: "",
  running: false,
  toast: "",
  toastT: 0,
  exLoad: 0,
  exDug: 0,
  exMoved: 0,
  exBoom: 0,
  exStick: 0,
  exBucket: 0,
  exSwing: 0,
  exDigging: false,
}));

export const toast = (msg: string) => useHud.setState({ toast: msg, toastT: Date.now() });
