import { afterEach, describe, expect, it } from "vitest";
import { resetDig } from "./dig";
import { EX, IDLE_INPUT, armPoints, createExcavatorSim, placeExcavator, stepExcavator, type ExInput, type ExSim } from "./excavator";
import { DIG_CELL, DIG_N, baseSurfaceAt, digGrid, heightAt, SURF } from "./world";

const deg = Math.PI / 180;

function run(sim: ExSim, seconds: number, inp: Partial<ExInput> = {}) {
  const base: ExInput = { ...IDLE_INPUT, engineOn: true, ...inp };
  for (let t = 0; t < seconds; t += 1 / 60) {
    stepExcavator(sim, base, 1 / 60);
    sim.events.length = 0;
  }
}

/** A spot on open grass (not road, yard or field edge) facing -z. */
function grassSim() {
  const sim = createExcavatorSim();
  run(sim, 2.5); // crank
  placeExcavator(sim, -62, 3, Math.PI);
  run(sim, 0.3);
  return sim;
}

afterEach(() => resetDig());

describe("excavator", () => {
  it("does not move or work the arm with the engine off", () => {
    const sim = createExcavatorSim();
    const { x, z, boom } = sim.ex;
    for (let t = 0; t < 1; t += 1 / 60) stepExcavator(sim, { ...IDLE_INPUT, drive: 1, boom: 1, engineOn: false }, 1 / 60);
    expect(Math.hypot(sim.ex.x - x, sim.ex.z - z)).toBeLessThan(0.01);
    expect(sim.ex.boom).toBeCloseTo(boom, 5);
  });

  it("drives forward once running", () => {
    const sim = createExcavatorSim();
    run(sim, 2.5);
    const { x, z } = sim.ex;
    run(sim, 3, { drive: 1 });
    expect(Math.hypot(sim.ex.x - x, sim.ex.z - z)).toBeGreaterThan(4);
  });

  it("keeps the arm inside its joint limits", () => {
    const sim = createExcavatorSim();
    run(sim, 2.5);
    run(sim, 10, { boom: 1, stick: 1, bucket: 1 });
    expect(sim.ex.boom).toBeLessThanOrEqual(EX.BOOM_MAX + 1e-9);
    expect(sim.ex.fold).toBeLessThanOrEqual(EX.FOLD_MAX + 1e-9);
    expect(sim.ex.curl).toBeLessThanOrEqual(EX.CURL_MAX + 1e-9);
  });

  it("parks the bucket above the ground", () => {
    const sim = createExcavatorSim();
    expect(sim.ex.tip.y).toBeGreaterThan(heightAt(sim.ex.tip.x, sim.ex.tip.z));
  });

  it("digs soil into the bucket and lowers the ground", () => {
    const sim = grassSim();
    run(sim, 2.5, { stick: -1 });
    run(sim, 2.5, { boom: -1 });
    run(sim, 1.2, { bucket: 1 });
    run(sim, 1.5, { stick: 1, boom: -0.3 });
    expect(sim.ex.bucketLoad).toBeGreaterThan(0.3);
    expect(sim.ex.dugM3).toBeGreaterThan(0.3);
    expect(Math.min(...digGrid)).toBeLessThan(-0.1);
  });

  it("dumps the load into a pile and conserves soil", () => {
    const sim = grassSim();
    run(sim, 2.5, { stick: -1 });
    run(sim, 2.5, { boom: -1 });
    run(sim, 1.2, { bucket: 1 });
    run(sim, 1.5, { stick: 1, boom: -0.3 });
    run(sim, 1.0, { boom: 0.9 });
    run(sim, 1.7, { swing: 1 });
    run(sim, 1.0, { boom: 0.6 });
    run(sim, 4, { bucket: -1 });
    expect(sim.ex.bucketLoad).toBeLessThan(0.05);
    expect(sim.ex.movedM3).toBeGreaterThan(0.3);
    expect(Math.max(...digGrid)).toBeGreaterThan(0.05);
    let sum = 0;
    for (const v of digGrid) sum += v;
    // everything dug is either in the pile or still in the bucket (terrain is scaled by TERRAIN_GAIN)
    expect((sum * DIG_CELL * DIG_CELL) / EX.TERRAIN_GAIN).toBeCloseTo(-sim.ex.bucketLoad, 1);
    expect(digGrid.length).toBe(DIG_N * DIG_N);
  });

  it("refuses to dig through asphalt", () => {
    const sim = createExcavatorSim();
    run(sim, 2.5);
    placeExcavator(sim, -62, -7, Math.PI / 2);
    Object.assign(sim.ex, { boom: 40 * deg, fold: 60 * deg, curl: 60 * deg, swing: 0 });
    run(sim, 0.2);
    expect(sim.ex.tip.y).toBeGreaterThan(heightAt(sim.ex.tip.x, sim.ex.tip.z)); // starts in the air
    run(sim, 6, { boom: -1 });
    const { tip } = sim.ex;
    expect(baseSurfaceAt(tip.x, tip.z)).not.toBe(SURF.grass);
    expect(Math.min(...digGrid)).toBe(0);
    expect(tip.y).toBeGreaterThanOrEqual(heightAt(tip.x, tip.z) - 0.05);
  });

  it("armPoints puts the tip below the pivot when the arm hangs down", () => {
    const a = armPoints(0, 100 * deg, 20 * deg);
    expect(a.p4.y).toBeLessThan(a.p1.y);
  });
});
