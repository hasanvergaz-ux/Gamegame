// Excavator simulation. Pure TypeScript: no React, no three.js.
// Same conventions as the tractor: world X east, Z south, Y up, yaw 0 faces +Z.
//
// The machine is a tracked chassis with a cab ("house") that swings on top of it. The arm lives in the
// vertical plane of the house and is described by three joint angles:
//   boom  – angle of the boom above horizontal
//   fold  – how far the stick is folded back against the boom (bigger = stick pointing more downward/back)
//   curl  – how far the bucket is curled in against the stick (bigger = bucket mouth faces more upward)
import { FieldMask } from "./field";
import { addSoil, removeSoil } from "./dig";
import { clamp, damp, lerp, wrapAngle } from "./math";
import { toWorld } from "./tractor";
import {
  COLLIDERS,
  DIG_MAX,
  EXCAVATOR_START,
  MAP_LIMIT,
  SURF,
  baseSurfaceAt,
  digAt,
  heightAt,
  isTillable,
  type Surface,
} from "./world";

const deg = Math.PI / 180;

export const EX = {
  HALF_LEN: 1.65, // half the length of a track on the ground
  HALF_GAUGE: 1.0, // track centre line from the machine centre
  TRACK_W: 0.7,
  /** boom foot pin in the house plane: r = forward of the swing axis, y = above the ground */
  PIVOT: { r: 0.95, y: 1.3 },
  HOUSE_Y: 1.0, // height of the swing ring above the ground
  BOOM_LEN: 4.2,
  STICK_LEN: 2.2,
  BUCKET_LEN: 1.05,
  BOOM_MIN: -25 * deg,
  BOOM_MAX: 62 * deg,
  FOLD_MIN: 25 * deg,
  FOLD_MAX: 158 * deg,
  CURL_MIN: -20 * deg,
  CURL_MAX: 140 * deg,
  RATE: { swing: 0.9, boom: 0.55, stick: 0.85, bucket: 1.4 },
  VMAX: 2.6, // 9.4 km/h
  ACCEL: 2.2,
  BRAKE: 4.0,
  TURN: 0.75,
  /** bucket capacity (m³) and the tip angle past which the mouth faces down and soil spills */
  CAP: 1.5,
  SPILL_ANGLE: -105 * deg,
  SPILL_RATE: 1.6,
  /** the 2 m ground grid is coarse, so one bucket changes the terrain this many times more than its own volume */
  TERRAIN_GAIN: 2.5,
  BODY_CIRCLES: [1.05, 0, -1.05],
  BODY_R: 1.5,
  IDLE_RPM: 900,
  MAX_RPM: 2100,
  CRANK_TIME: 2.0,
  /** pose the arm is parked in */
  REST: { boom: 20 * deg, fold: 125 * deg, curl: 100 * deg },
};

export type Excavator = {
  x: number; y: number; z: number; yaw: number; pitch: number; roll: number;
  v: number; yawRate: number;
  swing: number; boom: number; fold: number; curl: number;
  swingV: number; boomV: number; foldV: number; curlV: number;
  engine: boolean; running: boolean; crankEnd: number; t: number;
  rpm: number; load: number; surface: Surface;
  trackL: number; trackR: number;
  bucketLoad: number; dugM3: number; movedM3: number;
  digging: boolean; dumping: boolean; hydMoving: boolean;
  /** bucket tip and the point soil falls from, in world coordinates */
  tip: { x: number; y: number; z: number };
  prev: { x: number; y: number; z: number };
  drop: { x: number; y: number; z: number };
  tipSpeed: number;
  hasPrev: boolean;
  lastWarn: number; lastDigEvt: number;
};

export type ExInput = {
  drive: number; steer: number; swing: number; boom: number; stick: number; bucket: number; engineOn: boolean;
};

export type ExEvent =
  | { type: "crank" | "stall" | "noHydraulics" | "badGround" | "bucketOpen" | "bucketFull" | "dump" }
  | { type: "dig" | "bump"; strength: number };

export type ExSim = { ex: Excavator; mask: FieldMask; events: ExEvent[] };

export const IDLE_INPUT: ExInput = { drive: 0, steer: 0, swing: 0, boom: 0, stick: 0, bucket: 0, engineOn: false };

export function createExcavatorSim(mask = new FieldMask()): ExSim {
  const ex: Excavator = {
    x: 0, y: 0, z: 0, yaw: 0, pitch: 0, roll: 0, v: 0, yawRate: 0,
    swing: 0, boom: 0, fold: 0, curl: 0, swingV: 0, boomV: 0, foldV: 0, curlV: 0,
    engine: false, running: false, crankEnd: 0, t: 0, rpm: 0, load: 0, surface: SURF.concrete,
    trackL: 0, trackR: 0, bucketLoad: 0, dugM3: 0, movedM3: 0,
    digging: false, dumping: false, hydMoving: false,
    tip: { x: 0, y: 0, z: 0 }, prev: { x: 0, y: 0, z: 0 }, drop: { x: 0, y: 0, z: 0 }, tipSpeed: 0, hasPrev: false,
    lastWarn: -9, lastDigEvt: -9,
  };
  const sim: ExSim = { ex, mask, events: [] };
  resetExcavator(sim);
  return sim;
}

export function placeExcavator(sim: ExSim, x: number, z: number, yaw: number) {
  const ex = sim.ex;
  ex.x = x;
  ex.z = z;
  ex.yaw = yaw;
  ex.y = heightAt(x, z);
  ex.pitch = 0;
  ex.roll = 0;
  ex.v = 0;
  ex.yawRate = 0;
  ex.hasPrev = false;
}

export function resetExcavator(sim: ExSim) {
  const ex = sim.ex;
  placeExcavator(sim, EXCAVATOR_START.x, EXCAVATOR_START.z, EXCAVATOR_START.yaw);
  Object.assign(ex, {
    swing: 0, boom: EX.REST.boom, fold: EX.REST.fold, curl: EX.REST.curl,
    swingV: 0, boomV: 0, foldV: 0, curlV: 0, bucketLoad: 0, digging: false, dumping: false,
  });
  // settle the pose on the ground and compute the tip
  stepExcavator(sim, { ...IDLE_INPUT, engineOn: ex.engine }, 1 / 60);
  sim.events.length = 0;
}

/** Arm joint positions in the house plane (r = forward distance from the swing axis, y = height). */
export function armPoints(boom: number, fold: number, curl: number) {
  const a1 = boom;
  const a2 = boom - fold;
  const a3 = a2 - curl;
  const p1 = { r: EX.PIVOT.r, y: EX.PIVOT.y };
  const p2 = { r: p1.r + EX.BOOM_LEN * Math.cos(a1), y: p1.y + EX.BOOM_LEN * Math.sin(a1) };
  const p3 = { r: p2.r + EX.STICK_LEN * Math.cos(a2), y: p2.y + EX.STICK_LEN * Math.sin(a2) };
  const p4 = { r: p3.r + EX.BUCKET_LEN * Math.cos(a3), y: p3.y + EX.BUCKET_LEN * Math.sin(a3) };
  return { a1, a2, a3, p1, p2, p3, p4 };
}

/** House-plane point (r, y) -> world, for a given swing angle. */
export function armToWorld(ex: Excavator, swing: number, r: number, y: number, out: { x: number; y: number; z: number }) {
  return toWorld(ex, r * Math.sin(swing), y, r * Math.cos(swing), out);
}

const tmpA = { x: 0, y: 0, z: 0 };

function tipFor(ex: Excavator, boom: number, fold: number, curl: number, swing: number, out: { x: number; y: number; z: number }) {
  const a = armPoints(boom, fold, curl);
  return armToWorld(ex, swing, a.p4.r, a.p4.y, out);
}

/** Can the bucket dig here? Not through asphalt, concrete or buildings, and not below the deepest hole. */
export function diggable(x: number, z: number) {
  const s = baseSurfaceAt(x, z);
  if (s === SURF.asphalt || s === SURF.concrete) return false;
  if (!isTillable(x, z)) return false;
  return digAt(x, z) > -DIG_MAX + 0.1;
}

function collideCircle(ex: Excavator, lz: number, r: number) {
  const cx = ex.x + Math.sin(ex.yaw) * lz;
  const cz = ex.z + Math.cos(ex.yaw) * lz;
  let hit = false;
  for (const c of COLLIDERS) {
    const dx = cx - c.x;
    const dz = cz - c.z;
    if (Math.abs(dx) > 16 || Math.abs(dz) > 16) continue;
    if (c.k === "c") {
      const d = Math.hypot(dx, dz);
      const m = c.r + r;
      if (d < m && d > 1e-4) {
        ex.x += (dx / d) * (m - d);
        ex.z += (dz / d) * (m - d);
        hit = true;
      }
    } else {
      const lx = dx * c.c - dz * c.s;
      const lzz = dx * c.s + dz * c.c;
      const qx = clamp(lx, -c.hx, c.hx);
      const qz = clamp(lzz, -c.hz, c.hz);
      let nx = lx - qx;
      let nz = lzz - qz;
      let d = Math.hypot(nx, nz);
      let push = 0;
      if (d < 1e-4) {
        const px = c.hx - Math.abs(lx);
        const pz = c.hz - Math.abs(lzz);
        if (px < pz) { nx = Math.sign(lx) || 1; nz = 0; push = px + r; } else { nx = 0; nz = Math.sign(lzz) || 1; push = pz + r; }
        d = 1;
      } else if (d < r) push = r - d;
      if (push > 0) {
        nx /= d;
        nz /= d;
        ex.x += (nx * c.c + nz * c.s) * push;
        ex.z += (-nx * c.s + nz * c.c) * push;
        hit = true;
      }
    }
  }
  return hit;
}

const approach = (cur: number, target: number, step: number) => cur + clamp(target - cur, -step, step);

export function stepExcavator(sim: ExSim, inp: ExInput, dtIn: number) {
  const dt = Math.min(dtIn, 0.05);
  const { ex, mask } = sim;
  ex.t += dt;

  // ---- engine ----
  if (inp.engineOn && !ex.engine) {
    ex.engine = true;
    ex.crankEnd = ex.t + EX.CRANK_TIME;
    ex.rpm = 0;
    sim.events.push({ type: "crank" });
  } else if (!inp.engineOn && ex.engine) {
    ex.engine = false;
    sim.events.push({ type: "stall" });
  }
  const running = ex.engine && ex.t >= ex.crankEnd;
  ex.running = running;

  // ---- tracks ----
  const slope = Math.min(1, Math.abs(Math.sin(ex.pitch)) / 0.5);
  const driveIn = running ? clamp(inp.drive, -1, 1) : 0;
  const target = driveIn * EX.VMAX * (1 - 0.5 * slope);
  const braking = Math.sign(target) !== Math.sign(ex.v) || Math.abs(target) < Math.abs(ex.v);
  ex.v = approach(ex.v, target, (braking ? EX.BRAKE : EX.ACCEL) * dt);
  if (Math.abs(ex.v) < 0.01 && target === 0) ex.v = 0;
  const steerIn = running ? clamp(inp.steer, -1, 1) : 0;
  const wTarget = -steerIn * EX.TURN * (Math.abs(ex.v) > 0.3 ? 0.65 : 1);
  ex.yawRate = approach(ex.yawRate, wTarget, 3 * dt);
  ex.yaw = wrapAngle(ex.yaw + ex.yawRate * dt);
  ex.x += Math.sin(ex.yaw) * ex.v * dt;
  ex.z += Math.cos(ex.yaw) * ex.v * dt;
  if (Math.abs(ex.x) > MAP_LIMIT || Math.abs(ex.z) > MAP_LIMIT) {
    ex.x = clamp(ex.x, -MAP_LIMIT, MAP_LIMIT);
    ex.z = clamp(ex.z, -MAP_LIMIT, MAP_LIMIT);
    ex.v *= 0.5;
  }
  let hit = false;
  for (const lz of EX.BODY_CIRCLES) hit = collideCircle(ex, lz, EX.BODY_R) || hit;
  if (hit) {
    if (Math.abs(ex.v) > 1.2) sim.events.push({ type: "bump", strength: Math.abs(ex.v) });
    ex.v *= 0.3;
  }
  // a left turn (yaw rate > 0) makes the left track slower than the right one
  ex.trackL += (ex.v - ex.yawRate * EX.HALF_GAUGE) * dt;
  ex.trackR += (ex.v + ex.yawRate * EX.HALF_GAUGE) * dt;

  // ---- ground contact: the chassis rests on the four track corners ----
  const sy = Math.sin(ex.yaw);
  const cy = Math.cos(ex.yaw);
  const H = (lx: number, lz: number) => heightAt(ex.x + lx * cy + lz * sy, ex.z - lx * sy + lz * cy);
  const g = EX.HALF_GAUGE;
  const l = EX.HALF_LEN;
  const hFL = H(g, l);
  const hFR = H(-g, l);
  const hRL = H(g, -l);
  const hRR = H(-g, -l);
  const pitchT = Math.atan2((hFL + hFR) / 2 - (hRL + hRR) / 2, l * 2);
  const rollT = Math.atan2((hFL + hRL) / 2 - (hFR + hRR) / 2, g * 2);
  ex.pitch = lerp(ex.pitch, pitchT, damp(8, dt));
  ex.roll = lerp(ex.roll, rollT, damp(8, dt));
  ex.y = lerp(ex.y, (hFL + hFR + hRL + hRR) / 4, damp(12, dt));
  const base = baseSurfaceAt(ex.x, ex.z);
  ex.surface = base === SURF.asphalt || base === SURF.concrete ? base : mask.tilledAt(ex.x, ex.z) > 0.5 ? SURF.tilled : base;

  // ---- hydraulics ----
  const wantsArm = inp.swing !== 0 || inp.boom !== 0 || inp.stick !== 0 || inp.bucket !== 0;
  if (wantsArm && !running && ex.t - ex.lastWarn > 1.5) {
    ex.lastWarn = ex.t;
    sim.events.push({ type: "noHydraulics" });
  }
  const hyd = running ? (ex.digging ? 0.7 : 1) : 0;
  const acc = 5 * dt;
  ex.swingV = approach(ex.swingV, clamp(inp.swing, -1, 1) * EX.RATE.swing * hyd, acc);
  ex.boomV = approach(ex.boomV, clamp(inp.boom, -1, 1) * EX.RATE.boom * hyd, acc);
  ex.foldV = approach(ex.foldV, clamp(inp.stick, -1, 1) * EX.RATE.stick * hyd, acc);
  ex.curlV = approach(ex.curlV, clamp(inp.bucket, -1, 1) * EX.RATE.bucket * hyd, acc);
  ex.hydMoving = Math.abs(ex.swingV) + Math.abs(ex.boomV) + Math.abs(ex.foldV) + Math.abs(ex.curlV) > 0.02;

  const pb = ex.boom;
  const pf = ex.fold;
  const pc = ex.curl;
  const ps = ex.swing;
  ex.swing = wrapAngle(ex.swing + ex.swingV * dt);
  ex.boom = clamp(ex.boom + ex.boomV * dt, EX.BOOM_MIN, EX.BOOM_MAX);
  ex.fold = clamp(ex.fold + ex.foldV * dt, EX.FOLD_MIN, EX.FOLD_MAX);
  ex.curl = clamp(ex.curl + ex.curlV * dt, EX.CURL_MIN, EX.CURL_MAX);
  if (ex.boom === EX.BOOM_MIN || ex.boom === EX.BOOM_MAX) ex.boomV = 0;
  if (ex.fold === EX.FOLD_MIN || ex.fold === EX.FOLD_MAX) ex.foldV = 0;
  if (ex.curl === EX.CURL_MIN || ex.curl === EX.CURL_MAX) ex.curlV = 0;

  // the bucket may not be pushed into hard ground (asphalt, concrete, walls, the bottom of the hole)
  tipFor(ex, pb, pf, pc, ps, tmpA);
  const depthPrev = heightAt(tmpA.x, tmpA.z) - tmpA.y;
  const tip = ex.tip;
  tipFor(ex, ex.boom, ex.fold, ex.curl, ex.swing, tip);
  let depth = heightAt(tip.x, tip.z) - tip.y;
  if (depth > 0.03 && !diggable(tip.x, tip.z) && depth > depthPrev + 1e-4) {
    ex.boom = pb;
    ex.fold = pf;
    ex.curl = pc;
    ex.swing = ps;
    ex.boomV = ex.foldV = ex.curlV = ex.swingV = 0;
    if (ex.t - ex.lastWarn > 1.5) {
      ex.lastWarn = ex.t;
      sim.events.push({ type: "badGround" });
    }
    tipFor(ex, ex.boom, ex.fold, ex.curl, ex.swing, tip);
    depth = heightAt(tip.x, tip.z) - tip.y;
  }

  // ---- digging and dumping ----
  const arm = armPoints(ex.boom, ex.fold, ex.curl);
  const open = arm.a3 > EX.SPILL_ANGLE; // bucket mouth faces down
  ex.tipSpeed = ex.hasPrev ? Math.hypot(tip.x - ex.prev.x, tip.y - ex.prev.y, tip.z - ex.prev.z) / dt : 0;
  const wasDigging = ex.digging;
  ex.digging = false;
  ex.dumping = false;
  if (depth > 0.04 && diggable(tip.x, tip.z) && ex.tipSpeed > 0.1) {
    if (open) {
      if (ex.t - ex.lastWarn > 2) {
        ex.lastWarn = ex.t;
        sim.events.push({ type: "bucketOpen" });
      }
    } else if (ex.bucketLoad >= EX.CAP - 0.01) {
      if (ex.t - ex.lastWarn > 2) {
        ex.lastWarn = ex.t;
        sim.events.push({ type: "bucketFull" });
      }
    } else {
      const want = Math.min(EX.CAP - ex.bucketLoad, ex.tipSpeed * dt * 0.7 * Math.min(1, depth / 0.3));
      const got = removeSoil(tip.x, tip.z, tip.y, want * EX.TERRAIN_GAIN) / EX.TERRAIN_GAIN;
      if (got > 0) {
        ex.bucketLoad += got;
        ex.dugM3 += got;
        ex.digging = true;
        mask.paintTill(tip.x, tip.z, tip.x, tip.z, 1.3, isTillable);
        if (!wasDigging || ex.t - ex.lastDigEvt > 0.6) {
          ex.lastDigEvt = ex.t;
          sim.events.push({ type: "dig", strength: clamp(ex.tipSpeed, 0.3, 2) });
        }
      }
    }
  }
  if (open && ex.bucketLoad > 0.001) {
    const k = clamp((arm.a3 - EX.SPILL_ANGLE) / (50 * deg), 0.15, 1);
    const vol = Math.min(ex.bucketLoad, EX.SPILL_RATE * k * dt);
    const mid = armToWorld(ex, ex.swing, (arm.p3.r + arm.p4.r) / 2, (arm.p3.y + arm.p4.y) / 2, ex.drop);
    const placed = addSoil(mid.x, mid.z, vol * EX.TERRAIN_GAIN) / EX.TERRAIN_GAIN;
    ex.bucketLoad = Math.max(0, ex.bucketLoad - vol);
    ex.movedM3 += placed;
    ex.dumping = true;
    mask.paintTill(mid.x, mid.z, mid.x, mid.z, 1.5, isTillable);
    if (ex.t - ex.lastDigEvt > 0.8) {
      ex.lastDigEvt = ex.t;
      sim.events.push({ type: "dump" });
    }
  }
  ex.prev.x = tip.x;
  ex.prev.y = tip.y;
  ex.prev.z = tip.z;
  ex.hasPrev = true;

  // ---- engine speed & load ----
  const busy = running && (driveIn !== 0 || steerIn !== 0 || wantsArm);
  const loadT = running ? clamp((busy ? 0.25 : 0.05) + (ex.digging ? 0.55 : 0) + Math.abs(ex.v) * 0.05, 0, 1) : 0;
  ex.load = lerp(ex.load, loadT, damp(4, dt));
  if (running) {
    const rpmT = EX.IDLE_RPM + (busy ? 450 : 0) + ex.load * 600;
    ex.rpm = lerp(ex.rpm, clamp(rpmT, EX.IDLE_RPM * 0.9, EX.MAX_RPM), damp(4, dt));
  } else if (ex.engine) ex.rpm = 170 + 40 * Math.sin(ex.t * 25);
  else ex.rpm = lerp(ex.rpm, 0, damp(2.2, dt));
}
