// Moving soil: the bucket removes it from the ground and drops it somewhere else.
// Pure TypeScript. The ground is the 2 m node grid in world.ts (`digGrid`); volumes are in m³.
import {
  DIG_CELL,
  DIG_MAX,
  DIG_N,
  MAP_SIZE,
  digGrid,
  heightAt,
  markDigDirty,
  noteDigTouched,
} from "./world";

const CELL_AREA = DIG_CELL * DIG_CELL;
/** Steepest allowed height step between two neighbouring nodes (slope about 0.9). */
const REPOSE = DIG_CELL * 0.9;

const nodeX = (ix: number) => -MAP_SIZE / 2 + ix * DIG_CELL;

type Hit = { i: number; ix: number; iz: number; w: number; h: number };
const hits: Hit[] = [];

/** Collect the grid nodes within `radius` of (x,z) with a smooth weight (1 at the centre, 0 at the edge). */
function collect(x: number, z: number, radius: number, withHeight: boolean) {
  hits.length = 0;
  const ix0 = Math.max(0, Math.floor((x - radius + MAP_SIZE / 2) / DIG_CELL));
  const ix1 = Math.min(DIG_N - 1, Math.ceil((x + radius + MAP_SIZE / 2) / DIG_CELL));
  const iz0 = Math.max(0, Math.floor((z - radius + MAP_SIZE / 2) / DIG_CELL));
  const iz1 = Math.min(DIG_N - 1, Math.ceil((z + radius + MAP_SIZE / 2) / DIG_CELL));
  for (let iz = iz0; iz <= iz1; iz++) {
    for (let ix = ix0; ix <= ix1; ix++) {
      const nx = nodeX(ix);
      const nz = nodeX(iz);
      const d = Math.hypot(nx - x, nz - z);
      if (d >= radius) continue;
      const k = 1 - d / radius;
      hits.push({ i: iz * DIG_N + ix, ix, iz, w: k * k, h: withHeight ? heightAt(nx, nz) : 0 });
    }
  }
  return { ix0, ix1, iz0, iz1 };
}

/** Let steep soil slump into neighbouring nodes (mass is conserved). */
function relax(ix0: number, ix1: number, iz0: number, iz1: number) {
  for (let pass = 0; pass < 3; pass++) {
    let moved = false;
    for (let iz = Math.max(0, iz0 - 1); iz <= Math.min(DIG_N - 1, iz1 + 1); iz++) {
      for (let ix = Math.max(0, ix0 - 1); ix <= Math.min(DIG_N - 1, ix1 + 1); ix++) {
        const i = iz * DIG_N + ix;
        for (const [dx, dz] of [[1, 0], [0, 1]] as const) {
          const jx = ix + dx;
          const jz = iz + dz;
          if (jx >= DIG_N || jz >= DIG_N) continue;
          const j = jz * DIG_N + jx;
          const diff = digGrid[i]! - digGrid[j]!;
          if (Math.abs(diff) > REPOSE) {
            const m = (Math.abs(diff) - REPOSE) * 0.5 * Math.sign(diff);
            digGrid[i]! -= m;
            digGrid[j]! += m;
            moved = true;
          }
        }
      }
    }
    if (!moved) break;
  }
}

/**
 * Scoop up to `vol` m³ of soil around (x,z), lowering the nearby ground toward the bucket tip height.
 * Returns the volume actually removed.
 */
export function removeSoil(x: number, z: number, tipY: number, vol: number): number {
  if (vol <= 0) return 0;
  const R = 2.4;
  const box = collect(x, z, R, true);
  let total = 0;
  const share: number[] = [];
  for (const n of hits) {
    const room = digGrid[n.i]! + DIG_MAX; // how much deeper this node may still go
    const excess = Math.min(Math.max(0, n.h - tipY), room, 1.5);
    const s = excess > 0.005 ? n.w * excess : 0;
    share.push(s);
    total += s;
  }
  if (total < 1e-6) return 0;
  let removed = 0;
  hits.forEach((n, k) => {
    const s = share[k]!;
    if (s <= 0) return;
    const room = digGrid[n.i]! + DIG_MAX;
    const excess = Math.min(Math.max(0, n.h - tipY), room);
    const drop = Math.min(((vol * s) / total) / CELL_AREA, excess);
    digGrid[n.i]! -= drop;
    removed += drop * CELL_AREA;
  });
  noteDigTouched();
  relax(box.ix0, box.ix1, box.iz0, box.iz1);
  markDigDirty(box.ix0 - 3, box.ix1 + 3, box.iz0 - 3, box.iz1 + 3);
  return removed;
}

/** Drop `vol` m³ of soil onto the ground around (x,z). Returns the volume that actually stayed. */
export function addSoil(x: number, z: number, vol: number): number {
  if (vol <= 0) return 0;
  const R = 2.6;
  const box = collect(x, z, R, false);
  let total = 0;
  for (const n of hits) if (digGrid[n.i]! < DIG_MAX - 0.02) total += n.w;
  if (total < 1e-6) return 0;
  let placed = 0;
  for (const n of hits) {
    if (digGrid[n.i]! >= DIG_MAX - 0.02) continue;
    const rise = Math.min(((vol * n.w) / total) / CELL_AREA, DIG_MAX - digGrid[n.i]!);
    digGrid[n.i]! += rise;
    placed += rise * CELL_AREA;
  }
  noteDigTouched();
  relax(box.ix0, box.ix1, box.iz0, box.iz1);
  markDigDirty(box.ix0 - 3, box.ix1 + 3, box.iz0 - 3, box.iz1 + 3);
  return placed;
}

/** Put the ground back exactly as it was (used by tests and "reset terrain"). */
export function resetDig() {
  digGrid.fill(0);
  markDigDirty(0, DIG_N - 1, 0, DIG_N - 1);
}
