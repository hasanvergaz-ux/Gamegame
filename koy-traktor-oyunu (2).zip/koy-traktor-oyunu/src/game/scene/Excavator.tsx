// Procedurally built tracked excavator (no model file needed).
// Hierarchy:  root (chassis pose)  ->  house (swings)  ->  boom  ->  stick  ->  bucket.
// The joint angles come straight from the simulation, so what you see is exactly what digs.
import { useMemo } from "react";
import * as THREE from "three";
import { EX, armPoints, type ExSim } from "../sim/excavator";
import type { Toggles } from "../store";

const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
const UP = V(0, 1, 0);
const Z = V(0, 0, 1);

/** Stretch a unit-height (Y) mesh between two points. */
function between(m: THREE.Object3D, a: THREE.Vector3, b: THREE.Vector3) {
  const d = b.clone().sub(a);
  const len = d.length();
  m.position.copy(a).addScaledVector(d, 0.5);
  m.quaternion.setFromUnitVectors(UP, d.normalize());
  m.scale.set(1, len, 1);
}

/** Orient a unit-length (Z) box along a→b. */
function beam(parent: THREE.Object3D, mat: THREE.Material, a: THREE.Vector3, b: THREE.Vector3, w: number, h: number) {
  const d = b.clone().sub(a);
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, 1), mat);
  m.position.copy(a).addScaledVector(d, 0.5);
  m.quaternion.setFromUnitVectors(Z, d.clone().normalize());
  m.scale.set(1, 1, d.length());
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

function box(parent: THREE.Object3D, mat: THREE.Material, w: number, h: number, d: number, x: number, y: number, z: number) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

/** Cylinder whose axis runs along X (a pivot pin or a wheel). */
function pin(parent: THREE.Object3D, mat: THREE.Material, r: number, len: number, x: number, y: number, z: number) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 14), mat);
  m.rotation.z = Math.PI / 2;
  m.position.set(x, y, z);
  m.castShadow = true;
  parent.add(m);
  return m;
}

/** Point in a rotated plane frame (origin o, direction angle `ang`): zp along the part, yp perpendicular (up). */
function planePt(o: { r: number; y: number }, ang: number, yp: number, zp: number) {
  return {
    r: o.r + zp * Math.cos(ang) - yp * Math.sin(ang),
    y: o.y + zp * Math.sin(ang) + yp * Math.cos(ang),
  };
}

/** House plane (r, y above ground) -> house-local vector. */
const hv = (p: { r: number; y: number }, x = 0) => V(x, p.y - EX.HOUSE_Y, p.r);

// track loop: a stadium with straight length 2*S and end radius R
const TS = EX.HALF_LEN - 0.45;
const TR = 0.45;
const TRACK_LEN = 4 * TS + 2 * Math.PI * TR;
const PADS = 42;

function padPose(s: number, out: { z: number; y: number; rx: number }) {
  const p = ((s % TRACK_LEN) + TRACK_LEN) % TRACK_LEN;
  if (p < 2 * TS) {
    out.z = TS - p;
    out.y = 0.04;
    out.rx = 0;
  } else if (p < 2 * TS + Math.PI * TR) {
    const f = (p - 2 * TS) / TR;
    out.z = -TS - TR * Math.sin(f);
    out.y = TR - TR * Math.cos(f);
    out.rx = f;
  } else if (p < 4 * TS + Math.PI * TR) {
    out.z = -TS + (p - 2 * TS - Math.PI * TR);
    out.y = 2 * TR - 0.04;
    out.rx = Math.PI;
  } else {
    const f = (p - 4 * TS - Math.PI * TR) / TR;
    out.z = TS + TR * Math.sin(f);
    out.y = TR + TR * Math.cos(f);
    out.rx = Math.PI + f;
  }
}

export type ExcavatorRig = {
  root: THREE.Group;
  house: THREE.Group;
  /** operator's eye (inside the cab, turns with the house) */
  eye: THREE.Object3D;
  exhaust: THREE.Object3D;
  update: (sim: ExSim, tg: Toggles, t: number, dt: number) => void;
};

export function useExcavatorRig(): ExcavatorRig {
  return useMemo<ExcavatorRig>(() => {
    const paint = new THREE.MeshStandardMaterial({ color: "#e6a10f", roughness: 0.48, metalness: 0.25 });
    const paintDark = new THREE.MeshStandardMaterial({ color: "#b97c08", roughness: 0.55, metalness: 0.25 });
    const dark = new THREE.MeshStandardMaterial({ color: "#2a2c2f", roughness: 0.6, metalness: 0.6 });
    const weight = new THREE.MeshStandardMaterial({ color: "#3b3e42", roughness: 0.7, metalness: 0.5 });
    const rubber = new THREE.MeshStandardMaterial({ color: "#181818", roughness: 0.95, metalness: 0.05 });
    const steel = new THREE.MeshStandardMaterial({ color: "#8b9096", roughness: 0.35, metalness: 0.9 });
    const chrome = new THREE.MeshStandardMaterial({ color: "#d9dde0", roughness: 0.12, metalness: 1 });
    const glass = new THREE.MeshStandardMaterial({
      color: "#a9cfe0", roughness: 0.08, metalness: 0.1, transparent: true, opacity: 0.32, depthWrite: false,
    });
    const soilMat = new THREE.MeshStandardMaterial({ color: "#6a4e34", roughness: 1, metalness: 0 });
    const lensMat = new THREE.MeshStandardMaterial({ color: "#fff3c4", emissive: new THREE.Color("#fff3c4"), emissiveIntensity: 0, roughness: 0.3 });
    const amberMat = new THREE.MeshStandardMaterial({ color: "#ffa000", emissive: new THREE.Color("#ffa000"), emissiveIntensity: 0, roughness: 0.3 });

    const root = new THREE.Group();

    // ---------- undercarriage ----------
    box(root, dark, 1.6, 0.5, 2.6, 0, 0.62, 0);
    box(root, dark, 2.2, 0.3, 1.2, 0, 0.7, 0);
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.16, 28), steel);
    ring.position.y = 0.95;
    ring.castShadow = true;
    root.add(ring);

    const padGeo = new THREE.BoxGeometry(EX.TRACK_W - 0.04, 0.09, 0.2);
    const padMeshes: THREE.InstancedMesh[] = [];
    for (const sx of [1, -1]) {
      const x = sx * EX.HALF_GAUGE;
      box(root, dark, 0.36, 0.42, 2 * TS + 0.2, x, 0.5, 0);
      box(root, paintDark, EX.TRACK_W - 0.1, 0.1, 2 * TS + 0.5, x, 1.0, 0);
      const im = new THREE.InstancedMesh(padGeo, rubber, PADS);
      im.castShadow = true;
      im.receiveShadow = true;
      im.frustumCulled = false;
      root.add(im);
      padMeshes.push(im);
      // sprocket and idler at the track ends, and small road wheels along the bottom
      for (const z of [TS, -TS]) {
        pin(root, steel, 0.38, EX.TRACK_W - 0.2, x, TR, z);
        pin(root, paint, 0.14, EX.TRACK_W - 0.1, x, TR, z);
      }
      for (const z of [-0.7, 0, 0.7]) {
        pin(root, dark, 0.2, EX.TRACK_W - 0.16, x, 0.24, z);
      }
    }

    // ---------- house (swings) ----------
    const house = new THREE.Group();
    house.position.y = EX.HOUSE_Y;
    root.add(house);
    const slew = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.2, 28), dark);
    slew.position.y = 0.05;
    house.add(slew);
    box(house, paint, 2.5, 0.28, 3.2, 0, 0.24, -0.25); // deck, top at y = 0.38
    box(house, paint, 1.1, 0.95, 2.0, -0.65, 0.86, -0.55); // engine compartment
    for (let i = 0; i < 4; i++) box(house, dark, 0.9, 0.03, 0.08, -0.65, 1.35, -1.25 + i * 0.3); // louvres
    box(house, weight, 2.5, 0.9, 0.75, 0, 0.83, -1.85); // counterweight
    box(house, weight, 2.3, 0.1, 0.7, 0, 1.33, -1.85);
    box(house, paintDark, 0.3, 0.5, 2.4, 1.15, 0.7, -0.3); // left-side tool box
    // exhaust stack
    const stack = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.6, 10), dark);
    stack.position.set(-1.0, 1.65, -0.25);
    house.add(stack);
    const exhaust = new THREE.Object3D();
    exhaust.position.set(-1.0, 1.98, -0.25);
    house.add(exhaust);

    // cab on the left side
    const cab = new THREE.Group();
    cab.position.set(0.62, 0.38, 0.35);
    house.add(cab);
    box(cab, dark, 1.1, 0.06, 1.35, 0, 0.03, 0);
    for (const [px, pz] of [[-0.55, -0.67], [0.55, -0.67], [-0.55, 0.67], [0.55, 0.67]] as const) box(cab, dark, 0.07, 1.55, 0.07, px, 0.8, pz);
    box(cab, paint, 1.22, 0.08, 1.5, 0, 1.6, 0);
    box(cab, glass, 1.06, 1.35, 0.03, 0, 0.82, 0.68); // front
    box(cab, glass, 0.03, 1.35, 1.28, 0.55, 0.82, 0); // left
    box(cab, glass, 1.06, 1.1, 0.03, 0, 0.95, -0.68); // rear
    box(cab, dark, 0.46, 0.14, 0.46, 0, 0.45, -0.05); // seat
    box(cab, dark, 0.46, 0.6, 0.08, 0, 0.8, -0.3);
    box(cab, dark, 0.06, 0.28, 0.06, -0.3, 0.5, 0.2); // joysticks
    box(cab, dark, 0.06, 0.28, 0.06, 0.3, 0.5, 0.2);
    const eye = new THREE.Object3D();
    eye.position.set(0.62, 1.38, 0.2);
    house.add(eye);

    // lights (constant count; only intensities change)
    const head = new THREE.SpotLight("#fff1cf", 0, 70, 0.55, 0.5, 1.4);
    head.position.set(0.62, 2.0, 1.15);
    head.target.position.set(0.62, -1.5, 20);
    const work = new THREE.SpotLight("#fff6e0", 0, 35, 0.9, 0.6, 1.4);
    work.position.set(0, 1.9, 1.0);
    work.target.position.set(0, -1.5, 8);
    const beacon = new THREE.PointLight("#ffa000", 0, 16, 1.6);
    beacon.position.set(0.62, 2.35, -0.3);
    house.add(head, head.target, work, work.target, beacon);
    box(house, lensMat, 0.5, 0.1, 0.06, 0.62, 1.93, 1.1);
    const beaconMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.12, 10), amberMat);
    beaconMesh.position.set(0.62, 2.1, -0.3);
    house.add(beaconMesh);

    // ---------- arm ----------
    const boomG = new THREE.Group();
    boomG.position.set(0, EX.PIVOT.y - EX.HOUSE_Y, EX.PIVOT.r);
    house.add(boomG);
    box(boomG, dark, 0.8, 0.7, 0.5, 0, -0.05, -0.1);
    pin(boomG, steel, 0.11, 0.9, 0, 0, 0);
    // kinked boom
    const kink = V(0, 0.5, EX.BOOM_LEN * 0.52);
    beam(boomG, paint, V(0, 0, 0), kink, 0.42, 0.55);
    beam(boomG, paint, kink, V(0, 0, EX.BOOM_LEN), 0.4, 0.5);
    pin(boomG, steel, 0.1, 0.7, 0, 0, EX.BOOM_LEN);
    box(boomG, dark, 0.16, 0.2, 0.2, 0, 0.6, 3.0); // stick-ram mount

    const stickG = new THREE.Group();
    stickG.position.set(0, 0, EX.BOOM_LEN);
    boomG.add(stickG);
    const bend = V(0, 0.14, EX.STICK_LEN * 0.62);
    beam(stickG, paint, V(0, 0, 0), bend, 0.3, 0.42);
    beam(stickG, paint, bend, V(0, 0, EX.STICK_LEN), 0.27, 0.34);
    pin(stickG, steel, 0.09, 0.55, 0, 0, EX.STICK_LEN);
    box(stickG, dark, 0.16, 0.2, 0.2, 0, 0.34, 0.45); // stick-ram lug
    box(stickG, dark, 0.16, 0.2, 0.2, 0, 0.36, 1.55); // bucket-ram mount

    const bucketG = new THREE.Group();
    bucketG.position.set(0, 0, EX.STICK_LEN);
    stickG.add(bucketG);
    // bucket body: a D-shaped profile (z forward, y up) with the mouth facing down when curl = 0
    {
      const W = 1.2;
      const sh = new THREE.Shape();
      sh.moveTo(EX.BUCKET_LEN, -0.04);
      sh.lineTo(0.28, -0.12);
      sh.bezierCurveTo(-0.15, -0.05, -0.12, 0.62, 0.35, 0.72);
      sh.bezierCurveTo(0.75, 0.8, EX.BUCKET_LEN, 0.45, EX.BUCKET_LEN, -0.04);
      const g = new THREE.ExtrudeGeometry(sh, { depth: W, bevelEnabled: false, curveSegments: 14 });
      g.rotateY(-Math.PI / 2); // shape x -> local z, extrusion -> -x
      g.translate(W / 2, 0, 0);
      const body = new THREE.Mesh(g, paintDark);
      body.castShadow = true;
      body.receiveShadow = true;
      bucketG.add(body);
      for (let i = -2; i <= 2; i++) box(bucketG, steel, 0.09, 0.07, 0.22, i * 0.24, -0.06, EX.BUCKET_LEN + 0.02);
      box(bucketG, dark, 0.5, 0.12, 0.3, 0, 0.66, 0.3); // top bracket
    }
    pin(bucketG, steel, 0.08, 0.5, 0, 0, 0);
    // soil heaped in the bucket mouth
    const soil = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), soilMat);
    soil.rotation.x = Math.PI; // dome points out of the mouth (-y)
    soil.position.set(0, -0.1, 0.66);
    soil.castShadow = true;
    bucketG.add(soil);

    // hydraulic rams (barrel + chrome rod)
    const mkRam = (r: number) => {
      const barrel = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 1, 12), dark);
      const rod = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.55, r * 0.55, 1, 10), chrome);
      barrel.castShadow = true;
      house.add(barrel, rod);
      return { barrel, rod };
    };
    const boomRams = [mkRam(0.09), mkRam(0.09)];
    const stickRam = mkRam(0.1);
    const bucketRam = mkRam(0.08);
    const setRam = (ram: { barrel: THREE.Mesh; rod: THREE.Mesh }, a: THREE.Vector3, b: THREE.Vector3) => {
      const dir = b.clone().sub(a);
      const len = dir.length();
      dir.normalize();
      const bl = Math.min(len * 0.55, 1.1);
      between(ram.barrel, a, a.clone().addScaledVector(dir, bl));
      between(ram.rod, a.clone().addScaledVector(dir, bl * 0.8), b);
    };

    // ---------- track pads ----------
    const dummy = new THREE.Object3D();
    const pp = { z: 0, y: 0, rx: 0 };
    const setTracks = (dL: number, dR: number) => {
      padMeshes.forEach((im, k) => {
        const sx = k === 0 ? 1 : -1; // padMeshes[0] is the left track (+x)
        const dist = sx > 0 ? dL : dR;
        for (let i = 0; i < PADS; i++) {
          padPose((i / PADS) * TRACK_LEN + dist, pp);
          dummy.position.set(sx * EX.HALF_GAUGE, pp.y, pp.z);
          dummy.rotation.set(pp.rx, 0, 0);
          dummy.updateMatrix();
          im.setMatrixAt(i, dummy.matrix);
        }
        im.instanceMatrix.needsUpdate = true;
      });
    };

    const update = (sim: ExSim, tg: Toggles, t: number, dt: number) => {
      void dt;
      const ex = sim.ex;
      root.position.set(ex.x, ex.y, ex.z);
      root.rotation.set(-ex.pitch, ex.yaw, ex.roll, "YXZ");
      house.rotation.y = ex.swing;
      house.position.y = EX.HOUSE_Y + (ex.running ? Math.sin(t * 47) * 0.0025 + Math.sin(t * 29) * 0.0015 : 0);
      boomG.rotation.x = -ex.boom;
      stickG.rotation.x = ex.fold;
      bucketG.rotation.x = ex.curl;

      // tracks
      setTracks(ex.trackL, ex.trackR);

      // soil in the bucket
      const fill = ex.bucketLoad / EX.CAP;
      soil.visible = fill > 0.02;
      soil.scale.set(0.58, 0.06 + fill * 0.38, 0.46);

      // hydraulic rams, computed in the house plane
      const a = armPoints(ex.boom, ex.fold, ex.curl);
      const bFoot = { r: 0.55, y: EX.HOUSE_Y + 0.42 };
      const bAttach = planePt(a.p1, a.a1, 0.5, 1.3);
      boomRams.forEach((ram, i) => {
        const x = i === 0 ? 0.24 : -0.24;
        setRam(ram, hv(bFoot, x), hv(bAttach, x));
      });
      const sBase = planePt(a.p1, a.a1, 0.6, 3.0);
      const sLug = planePt(a.p2, a.a2, 0.34, 0.45);
      setRam(stickRam, hv(sBase), hv(sLug));
      const kBase = planePt(a.p2, a.a2, 0.36, 1.55);
      const kLug = planePt(a.p3, a.a3, 0.66, 0.3);
      setRam(bucketRam, hv(kBase), hv(kLug));

      // lights
      const h = tg.head ? 1 : 0;
      lensMat.emissiveIntensity = h * 3;
      head.intensity = h * 70;
      work.intensity = tg.work ? 50 : 0;
      const bk = tg.beacon && Math.sin(t * 9) > 0 ? 1 : tg.beacon ? 0.12 : 0;
      amberMat.emissiveIntensity = bk * 4;
      beacon.intensity = bk * 6;
    };

    return { root, house, eye, exhaust, update };
  }, []);
}
