// Shared GPU resources: the soil mask texture, terrain height & grass-density textures,
// and the time uniform every swaying plant reads.
import * as THREE from "three";
import { FieldMask } from "../sim/field";
import { MAP_SIZE, SURF, baseSurfaceAt, digDirty, digGrid, heightAt, inRect, markDigDirty, DIG_N, FIELDS, COLLIDERS } from "../sim/world";

export const uTime = { value: 0 };
export const mask = new FieldMask(2048);

let maskTex: THREE.DataTexture | null = null;
export function getMaskTexture() {
  if (!maskTex) {
    maskTex = new THREE.DataTexture(mask.data, mask.n, mask.n, THREE.RGBAFormat, THREE.UnsignedByteType);
    maskTex.magFilter = THREE.LinearFilter;
    maskTex.minFilter = THREE.LinearMipmapLinearFilter;
    maskTex.generateMipmaps = true;
    maskTex.wrapS = maskTex.wrapT = THREE.ClampToEdgeWrapping;
    maskTex.needsUpdate = true;
  }
  return maskTex;
}

/** Push changed rows of the soil mask to the GPU. */
export function uploadMask() {
  const t = getMaskTexture();
  const n = mask.n;
  const any = mask.consumeDirty((row, c0, c1) => {
    t.addUpdateRange((row * n + c0) * 4, (c1 - c0 + 1) * 4);
  });
  if (any) t.needsUpdate = true;
}

// Terrain grid: 2 m cells over the inner map. The mesh and the grass both read these heights.
export const GRID = 300;
export const CELL = MAP_SIZE / GRID;
let heights: Float32Array | null = null;
/** Natural ground height at each node (without anything the excavator moved). */
let baseHeights: Float32Array | null = null;
export function getHeights() {
  if (!heights) {
    const n = GRID + 1;
    heights = new Float32Array(n * n);
    baseHeights = new Float32Array(n * n);
    for (let iz = 0; iz < n; iz++)
      for (let ix = 0; ix < n; ix++) {
        const i = iz * n + ix;
        const h = heightAt(-MAP_SIZE / 2 + ix * CELL, -MAP_SIZE / 2 + iz * CELL);
        heights[i] = h;
        baseHeights[i] = h - digGrid[i]!;
      }
  }
  return heights;
}

/** The inner terrain mesh, registered by <Terrain/> so dug ground can be written into it. */
export const terrainRef: { geo: THREE.BufferGeometry | null } = { geo: null };
export function markTerrainAllDirty() {
  markDigDirty(0, DIG_N - 1, 0, DIG_N - 1);
}

let heightTex: THREE.DataTexture | null = null;
export function getHeightTexture() {
  if (!heightTex) {
    heightTex = new THREE.DataTexture(getHeights(), GRID + 1, GRID + 1, THREE.RedFormat, THREE.FloatType);
    heightTex.magFilter = heightTex.minFilter = THREE.NearestFilter;
    heightTex.needsUpdate = true;
  }
  return heightTex;
}

/** Where wild grass grows (0..1), sampled on the same 2 m grid. */
let densityTex: THREE.DataTexture | null = null;
let densityData: Uint8Array | null = null;
let densityBase: Uint8Array | null = null;
export function getDensityTexture() {
  if (!densityTex) {
    const n = GRID;
    const d = new Uint8Array(n * n);
    for (let iz = 0; iz < n; iz++)
      for (let ix = 0; ix < n; ix++) {
        const x = -MAP_SIZE / 2 + (ix + 0.5) * CELL;
        const z = -MAP_SIZE / 2 + (iz + 0.5) * CELL;
        const s = baseSurfaceAt(x, z);
        let v = s === SURF.grass ? 1 : 0;
        if (v) {
          for (const f of FIELDS) if (inRect(x, z, { x0: f.x0 - 1.5, z0: f.z0 - 1.5, x1: f.x1 + 1.5, z1: f.z1 + 1.5 })) v = 0;
          for (const c of COLLIDERS)
            if (c.k === "b") {
              const dx = x - c.x;
              const dz = z - c.z;
              if (Math.abs(dx * c.c - dz * c.s) < c.hx + 0.5 && Math.abs(dx * c.s + dz * c.c) < c.hz + 0.5) v = 0;
            }
        }
        d[iz * n + ix] = v * 255;
      }
    densityData = d;
    densityBase = Uint8Array.from(d);
    densityTex = new THREE.DataTexture(d, n, n, THREE.RedFormat, THREE.UnsignedByteType);
    densityTex.magFilter = densityTex.minFilter = THREE.LinearFilter;
    densityTex.needsUpdate = true;
  }
  return densityTex;
}

/**
 * Write soil the excavator moved into the terrain mesh, the height texture (used by the grass)
 * and the grass density, for the nodes that changed since the last call.
 */
export function syncDug() {
  if (!digDirty.any) return;
  const { ix0, ix1, iz0, iz1 } = digDirty;
  digDirty.any = false;
  const n = GRID + 1;
  const h = getHeights();
  const base = baseHeights!;
  for (let iz = iz0; iz <= iz1; iz++)
    for (let ix = ix0; ix <= ix1; ix++) {
      const i = iz * n + ix;
      h[i] = base[i]! + digGrid[i]!;
    }
  const geo = terrainRef.geo;
  if (geo) {
    const pos = geo.attributes.position as THREE.BufferAttribute;
    const nor = geo.attributes.normal as THREE.BufferAttribute;
    for (let iz = Math.max(0, iz0 - 1); iz <= Math.min(n - 1, iz1 + 1); iz++)
      for (let ix = Math.max(0, ix0 - 1); ix <= Math.min(n - 1, ix1 + 1); ix++) {
        const i = iz * n + ix;
        pos.setY(i, h[i]!);
        const nx = h[iz * n + Math.max(0, ix - 1)]! - h[iz * n + Math.min(n - 1, ix + 1)]!;
        const nz = h[Math.max(0, iz - 1) * n + ix]! - h[Math.min(n - 1, iz + 1) * n + ix]!;
        const ny = 2 * CELL;
        const len = Math.hypot(nx, ny, nz) || 1;
        nor.setXYZ(i, nx / len, ny / len, nz / len);
      }
    pos.needsUpdate = true;
    nor.needsUpdate = true;
  }
  if (heightTex) heightTex.needsUpdate = true;
  if (densityTex && densityData && densityBase) {
    // no wild grass where the ground was dug or piled up
    for (let iz = Math.max(0, iz0 - 1); iz <= Math.min(GRID - 1, iz1); iz++)
      for (let ix = Math.max(0, ix0 - 1); ix <= Math.min(GRID - 1, ix1); ix++) {
        const a = Math.abs(digGrid[iz * n + ix]!);
        const b = Math.abs(digGrid[iz * n + ix + 1]!);
        const c = Math.abs(digGrid[(iz + 1) * n + ix]!);
        const d = Math.abs(digGrid[(iz + 1) * n + ix + 1]!);
        const i = iz * GRID + ix;
        densityData[i] = Math.max(a, b, c, d) > 0.1 ? 0 : densityBase[i]!;
      }
    densityTex.needsUpdate = true;
  }
}
