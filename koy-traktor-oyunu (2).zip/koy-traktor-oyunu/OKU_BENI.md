# Köy Traktör Oyunu

Tarayıcıda çalışan 3D traktör oyunu: gerçekçi dokulu köy haritası, arka kaldırıcı (3 nokta askı) ve kazayağı ile toprak işleme, çamurlu çukurlar, gece/gündüz, motor sesi ve ağır korna.

## Çalıştırma

Bilgisayarında [Node.js](https://nodejs.org) (20 veya üstü) ya da [Bun](https://bun.sh) kurulu olmalı.

```bash
npm install      # veya: bun install
npm run dev      # veya: bun run dev
```

Sonra terminalde yazan adresi (genelde http://localhost:8080 veya http://localhost:3000) tarayıcıda aç.

Testleri çalıştırmak için: `npm test`

## Kontroller

| Tuş | İş |
| --- | --- |
| K | Kontak (motoru çalıştır / durdur) |
| W / S (veya ↑ / ↓, Boşluk) | Gaz / fren |
| A / D (veya ← / →) | Direksiyon |
| R | İleri ⇄ geri vites |
| E / Q | Arka kolları kaldır / indir |
| T | Aleti tak / çıkar |
| H | Korna |
| C | Kamera değiştir |
| L / J / B | Far / iş lambası / çakar |
| N | Gece ⇄ gündüz |
| O | Kaputu aç / kapat |
| F1 | Tuş listesi |

Telefonda ekrandaki düğmeler kullanılır.

## Klasörler (başka bir yapay zekaya anlatırken işine yarar)

- `src/game/sim/` – Oyunun kuralları: harita ve arazi yüksekliği (`world.ts`), traktör fiziği (`tractor.ts`), arka askı ve kazayağı ölçüleri (`hitch.ts`), sürülmüş toprak haritası (`field.ts`). Testleri: `tractor.test.ts`.
- `src/game/scene/` – Ekranda çizilenler: arazi, bitkiler, evler, traktör, kazayağı, toz/duman.
- `src/game/audio/GameAudio.ts` – Motor, korna, hidrolik ve toprak sesleri.
- `src/game/ui/` – Gösterge paneli, düğmeler, mini harita.
- `src/game/Game.tsx` – Her kareyi yöneten ana döngü, kamera, ışık ve gece/gündüz.
- `public/game-assets/` – Traktör modeli, dokular, bitki görselleri ve motor sesleri.

Kullanılan teknolojiler: React 19, TanStack Start, Vite, Three.js, React Three Fiber, Tailwind CSS.
Dokular Poly Haven'dan (CC0, serbest kullanım). Traktör modeli ve motor sesi senin yüklediğin orijinal oyundan.

## Ekskavatör

`V` tuşu (veya üst çubuktaki 🚜/🏗️ düğmesi) traktör ile ekskavatör arasında geçiş yapar.
Ekskavatör çiftlik avlusunun kenarında (-62, 12) bekler; kazmak için çimenli/topraklı bir alana sür.

| Tuş | İş |
| --- | --- |
| K | Kontak (hidrolik için motor çalışmalı) |
| W S / ↑ ↓ | İleri / geri |
| A D / ← → | Dön (palet) |
| Q E | Kabini sola / sağa çevir |
| R F | Bom yukarı / aşağı |
| T G | Dirsek aç / çek |
| X Z | Kova kıvır (ağzı yukarı) / aç (boşalt) |
| C | Kamera: dış / kabin / kova |

Kazma: kolu uzat (T), bomu indir (F), kovayı kıvır (X), dirseği çek (G). Kova doluyunca kabini çevir (Q/E),
bomu kaldır ve kovayı aç (Z): toprak yığın olur. Asfalt, beton, bina ve 3 m'den derin çukur kazılamaz.

Kod:
- `src/game/sim/excavator.ts`: fizik ve kol kinematiği (saf TypeScript, testli: `excavator.test.ts`)
- `src/game/sim/dig.ts`: toprağı kaldırma/yığma (hacim korunur, dik yamaçlar çöker)
- `src/game/sim/world.ts`: `digGrid` (kazı katmanı), `heightAt` artık kazıyı da içerir
- `src/game/scene/Excavator.tsx`: 3B model (dışarıdan model dosyası gerekmez)
- `src/game/scene/shared.ts`: `syncDug()` kazıyı arazi mesh'ine, yükseklik dokusuna ve ot yoğunluğuna yazar
